-- Startup script
-- Changes will take effect once Notepad++ is restarted
editor1.IndicAlpha[29] = 255
editor2.IndicAlpha[29] = 255
